""" Removes duplicate entries that appeared because of the code used to generate sentiment files. This is the one used for
infaltion, it was changed on the notated line (HERE) for each term and thus there is only the one file"""

import os
import pandas as pd

readpath = "C:\\Users\\awyat049\\OneDrive\\Documents\\Coding\\2022_11_29_Final_Data_Full"
writepath = "D:\\Documents\\Coding\\Twitter_Scrape\\Sentiment_backup\\Removed Dupes"

os.chdir(readpath)

# read in the specified file
data = pd.read_csv('inflation_clean_all_tweets_sentiment.csv') # HERE -- change this path to select different file to remove dupes

#  drop a useless column
data = data.drop(columns = 'Unnamed: 0')

# drop all duplicates
data.drop_duplicates(subset=None,inplace=True)

#save as a new file
data.to_csv('inflation_sentiment.csv', index=False)
