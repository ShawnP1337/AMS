""" combines the different parts of sentiment analysed tweets for inflation, since parallel calculation
they were all in different files based on block calculated and had to be combined into one"""

import os
import pandas as pd
import glob
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer

path = "C:\\Users\\awyat049\\OneDrive\\Documents\\Coding\\2022_11_29_Final_Data_Full\\inflation_clean"

os.chdir(path)

filename = path[71:]

extension = 'csv'

newname = filename + "_all_tweets_sentiment.csv"

#collects filenames of all csv file to be combined
all_filenames = [i for i in glob.glob('*.{}'.format(extension))]

#combines using pandas (the speed of pandas is unbelievable)
combined_csv = pd.concat([pd.read_csv(f) for f in all_filenames ])

# saves new file with appropriate filename
combined_csv.to_csv( newname, index=False, encoding='utf-8-sig')
