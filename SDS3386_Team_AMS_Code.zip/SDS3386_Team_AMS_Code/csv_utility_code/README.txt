combinecsv.py was only used to combine the different csv's created from calculating sentiment for infaltion in parallel. It should be run before removeduplicates.py

removeduplicates.py was needed as the method used to collect filenames 

(all_filenames = [i for i in glob.glob('*.{}'.format(extension))])

of scraped tweet csv's and combine them into a single csv produced some duplicate entries if there was a failure at any point (since it output the combined file before analysing sentiment). This is run after all sentiment analysis is performed to ensure there are no over-represented results.