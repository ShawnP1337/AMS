All code in this folder accomplish the same task for different terms, that is, to calculate the sentiment score of all scraped
tweets for the given term. The term in question is the name of the file, and the only change between files is the directory
where that code is accessed. 

As a result, only the first file will be commented "affordable_housing.py" for reference, but the comments in said file apply to all files in this folder 
**other than inflation, which was so large that it needed to have a separate parallel implementation for just that file.

RUNNING FILES

In the folder "Scripts_to_Run_Parallel", are 5 script files that are used to run all of the python scripts for calculating sentiment score in parallel. 
Python files are split into 5 subgroups because running all at once bottlenecked the CPU, so they were run in stages. This implementation allows for separate 
python processes to calculate sentiment score on different files at the same time, which saved hours of running the computer.

How to run: These files are run through BASH. We used gitbash. In gitbash, navigate to the appropriate directory, type

./script.sh

where script.sh is the appropriate script name.