#!/bin/bash

python inflation60.py &
python inflation61.py &
python inflation62.py &
python inflation63.py &
python inflation64.py &
python inflation65.py &
python inflation66.py &
python inflation67.py &
python inflation68.py &
python inflation69.py &
