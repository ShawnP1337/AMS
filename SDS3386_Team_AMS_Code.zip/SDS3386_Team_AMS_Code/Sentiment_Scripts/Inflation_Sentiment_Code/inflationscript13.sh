#!/bin/bash

python inflation120.py &
python inflation121.py &
python inflation122.py &
python inflation123.py &
python inflation124.py &
python inflation125.py &
python inflation126.py &
python inflation127.py &
python inflation128.py &
python inflation129.py &
