#!/bin/bash
python inflation1.py &
python inflation2.py &
python inflation3.py &
python inflation4.py &
python inflation5.py &
python inflation6.py &
python inflation7.py &
python inflation8.py &
python inflation9.py &
