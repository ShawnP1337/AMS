#!/bin/bash

python inflation10.py &
python inflation11.py &
python inflation12.py &
python inflation13.py &
python inflation14.py &
python inflation15.py &
python inflation16.py &
python inflation17.py &
python inflation18.py &
python inflation19.py &
