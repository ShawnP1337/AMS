#!/bin/bash

python inflation100.py &
python inflation101.py &
python inflation102.py &
python inflation103.py &
python inflation104.py &
python inflation105.py &
python inflation106.py &
python inflation107.py &
python inflation108.py &
python inflation109.py &
