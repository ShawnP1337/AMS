#!/bin/bash

python inflation130.py &
python inflation131.py &
python inflation132.py &
python inflation133.py &
python inflation134.py &
python inflation135.py &
python inflation136.py &
python inflation137.py &
python inflation138.py &
python inflation139.py &
