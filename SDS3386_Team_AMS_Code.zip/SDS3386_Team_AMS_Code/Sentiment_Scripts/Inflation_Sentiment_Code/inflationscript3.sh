#!/bin/bash

python inflation20.py &
python inflation21.py &
python inflation22.py &
python inflation23.py &
python inflation24.py &
python inflation25.py &
python inflation26.py &
python inflation27.py &
python inflation28.py &
python inflation29.py &
