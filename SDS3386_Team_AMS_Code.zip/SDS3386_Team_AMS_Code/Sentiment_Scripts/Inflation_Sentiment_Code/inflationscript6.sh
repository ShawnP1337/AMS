#!/bin/bash

python inflation50.py &
python inflation51.py &
python inflation52.py &
python inflation53.py &
python inflation54.py &
python inflation55.py &
python inflation56.py &
python inflation57.py &
python inflation58.py &
python inflation59.py &
