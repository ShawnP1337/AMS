""" Generates all script files needed to run sentiment calculator python files in parallel. Each script file includes up to
10 python files to run This is the version used to generate all files to calculate sentiment of the inflation dataset (146 python scripts)"""

filestring = "inflationscript"

#new file to write to, this is the name of the first script file. Further names are dynamically generated within the for loop.
f = open("inflationscript1.sh", "w")

count = 2

basestring = "python inflation"

# necessary to make the script file executable, the first line in each script file
f.write("#!/bin/bash\n")

# range 1 to 147 since the first inflation python file is numbered 1 instead of 0.
for i in range(1,147):
    #if 10 file run commands are added, close the current sh file, make a new one, and append the next entry in there.
    if (i%10 == 0):
        f.close()
        currfilename = filestring + str(count) + ".sh"
        f = open(currfilename, "w")
        count = count + 1
        # make file executable and add first run command
        f.write("#!/bin/bash\n\n" + basestring + str(i) + ".py &\n")
    
    # if haven't reached 10 files within, write a line to run the next python file, next iteration
    else:
        f.write(basestring + str(i) + ".py &\n")