#!/bin/bash

python inflation140.py &
python inflation141.py &
python inflation142.py &
python inflation143.py &
python inflation144.py &
python inflation145.py &
python inflation146.py &
