#!/bin/bash

python inflation70.py &
python inflation71.py &
python inflation72.py &
python inflation73.py &
python inflation74.py &
python inflation75.py &
python inflation76.py &
python inflation77.py &
python inflation78.py &
python inflation79.py &
