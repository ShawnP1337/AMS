#!/bin/bash

python inflation30.py &
python inflation31.py &
python inflation32.py &
python inflation33.py &
python inflation34.py &
python inflation35.py &
python inflation36.py &
python inflation37.py &
python inflation38.py &
python inflation39.py &
