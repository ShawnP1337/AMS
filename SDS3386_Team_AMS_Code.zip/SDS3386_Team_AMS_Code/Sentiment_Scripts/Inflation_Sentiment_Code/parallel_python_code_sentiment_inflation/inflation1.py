""" Calculates VADER sentiment on subset of infaltion files determined by "start" and "stop:" integer variables.
 Outputs a csv of the results, all output csv's are later combined (using 'combinecsv.py) once all calculations are complete.
 For PARALLEL CALCULATION of sentiment"""

import os
import pandas as pd
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
import csv

path = "C:\\Users\\awyat049\\OneDrive\\Documents\\Coding\\2022_11_26_Cleaned_Twitter_Data\\inflation"

#change these to change files
start = 0
stop = 5

os.chdir(path)

#converts numeric sentiment score into string classifier
#input: float64 sentiment_score
#output: string classifier as "Positive", "Negative", or "Neutral" sentiment
def calculateCompoundSentiment(sentiment_score):
    # decide sentiment as positive, negative and neutral based on numeric sentiment value
    if sentiment_score['compound'] >= 0.05 :
        return "Positive"
 
    elif sentiment_score['compound'] <= -0.05 :
        return "Negative"
 
    else :
        return "Neutral"

#uses vader to calculate numeric sentiment score of string
#input: string sentence - in this case a tweet
#output: string "sentiment_score, sentiment classifier"
## output example: '({'neg': 0.205, 'neu': 0.795, 'pos': 0.0, 'compound': -0.5574}, 'Negative')'
def getVaderSentimentScore(sentence):
    analyzer = SentimentIntensityAnalyzer()

    #calculates numeric sentiment score for negative, neutral, and positive sentiment
    sentiment_score = analyzer.polarity_scores(sentence)

    #classifies sentiment as negative, neutral or positive
    compoundSentiment = calculateCompoundSentiment(sentiment_score)
    return sentiment_score, compoundSentiment

all_filenames = []

#opens in inflation file list csv file appends all files into a list
with open('inflationfilelist.csv', newline='') as inputfile:
    for row in csv.reader(inputfile):
        all_filenames.append(row[0])

#print(len(all_filenames))
#730

#Range is inclusive in python so range(3,6) prints 3,4,5
#Iterates through given range using subscripting in created list of filenames and analyses csv files in those indices
for f in range(start,stop):
    os.chdir(path)
    filename = all_filenames[f]
    data = pd.read_csv(filename)
    data = data.dropna(subset=["tweet"])

    # converts to numpy array for use by vader
    tweetsArr = data['tweet'].to_numpy()
    list = []

    #analyses sentiment of each tweet and appends to final list
    for tweet in tweetsArr:
        vs = getVaderSentimentScore(tweet)
        list.append(str(vs))

    #adds sentiment list as column to original scraped data
    data['Sentiment'] = list

    finalfile = filename + '_sentiment.csv'
    os.chdir("C:\\Users\\awyat049\\OneDrive\\Documents\\Coding\\2022_11_29_Final_Data_Full\\inflation_clean")

    #outputs file of all data including sentiment data as csv into new directory
    data.to_csv(finalfile)