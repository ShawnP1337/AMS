The inflation dataset alone was over 6 gb, and as a result, sentiment calculation orginally ran for 2 days straight, then my computer crashed (Alex). In response, a parallel implementation was made which sections the inflation set into sets of 5 files, where each file is a 3 day date range of scraped tweets. This resulted in 146 python files for calculating inflation.

Each of these 146 files is identical other than the variables "start" and "stop" which are used in the 'for' loop below to determine which files of tweets are analyzed. These python files themselves are the same as the files used to calculate sentiment scores of other terms, except for the added mechanism to select a subset of files to analyse.

savefilelist_inflation.py - run first to generate list of all scraped filenames with inflation data within the given directory (listed within the file)

Then, inflation 1 through 146 are created to perform the analysis later. These weren't generated because I was between classes and didn't want to think, so I wrote the files in a way that was really easy to do by hand. Kind of therapeutic.

generatescriptfiles.py - run next to generate script files based on the names of inflation1 through 146

In BASH, (I used gitbash) run script files as possible by computer to calculate inflation sentiment score in parallel. ./"inflation script filename".sh

**for the python inflation files, only inflation1.py is commented as all other files are the same other than the 'start' and 'stop' variables.