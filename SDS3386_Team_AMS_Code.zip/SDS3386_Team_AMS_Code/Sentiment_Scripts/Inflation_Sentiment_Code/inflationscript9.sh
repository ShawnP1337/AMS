#!/bin/bash

python inflation80.py &
python inflation81.py &
python inflation82.py &
python inflation83.py &
python inflation84.py &
python inflation85.py &
python inflation86.py &
python inflation87.py &
python inflation88.py &
python inflation89.py &
