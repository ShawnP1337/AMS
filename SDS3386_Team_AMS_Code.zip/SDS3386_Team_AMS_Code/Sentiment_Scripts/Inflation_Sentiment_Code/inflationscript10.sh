#!/bin/bash

python inflation90.py &
python inflation91.py &
python inflation92.py &
python inflation93.py &
python inflation94.py &
python inflation95.py &
python inflation96.py &
python inflation97.py &
python inflation98.py &
python inflation99.py &
