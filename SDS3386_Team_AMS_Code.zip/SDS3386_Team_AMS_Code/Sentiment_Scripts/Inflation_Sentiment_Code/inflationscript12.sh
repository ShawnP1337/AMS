#!/bin/bash

python inflation110.py &
python inflation111.py &
python inflation112.py &
python inflation113.py &
python inflation114.py &
python inflation115.py &
python inflation116.py &
python inflation117.py &
python inflation118.py &
python inflation119.py &
