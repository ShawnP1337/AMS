""" Generates a static list of filenames for inflation parallel sentiment analysis algorithm to iterate through, ensures that
there are no double or mislabelled calculations"""

import glob
import os

path = "C:\\Users\\awyat049\\OneDrive\\Documents\\Coding\\2022_11_26_Cleaned_Twitter_Data\\inflation"
os.chdir(path)

#name of new csv file containing static list of all inflation related filenames
f = open("inflationfilelist.csv", "w")

extension = 'csv'

# collects all files wtih extension 'csv' from the given the directory and returns them in a list
all_filenames = [i for i in glob.glob('*.{}'.format(extension))]

#writes filenames to a new csv file
for i in all_filenames:
    f.write('"' + i + '"\n')

f.close()