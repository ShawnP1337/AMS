#!/bin/bash

python inflation40.py &
python inflation41.py &
python inflation42.py &
python inflation43.py &
python inflation44.py &
python inflation45.py &
python inflation46.py &
python inflation47.py &
python inflation48.py &
python inflation49.py &
