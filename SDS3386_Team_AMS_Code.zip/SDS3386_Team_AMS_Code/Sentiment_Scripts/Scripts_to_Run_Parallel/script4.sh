#!/bin/bash

python property_tax_canada.py &
python rental_market.py &
python rising_price_home.py &
python rising_price_housing.py &
python Rising_prices.py &
python rising_prices_home.py &
python rising_prices_housing.py &
python social_assistance.py &
python standard_of_living.py &