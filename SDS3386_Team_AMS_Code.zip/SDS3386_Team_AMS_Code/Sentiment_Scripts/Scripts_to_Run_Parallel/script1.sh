#!/bin/bash

python affordable_housing.py &
python cost_of_living.py &
python Foreign_Buyer.py &
python foreign_buyer_ban.py &
python foreign_home_buyer.py &
python foreign_investors.py &
python Freedom_Convoy.py &
