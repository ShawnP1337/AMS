#!/bin/bash

python Generational_Wealth.py &
python home_owner.py &
python housing_crisis.py &
python housing_market.py &
python Increase_of_prices.py &
python increase_price_home.py &
python increase_price_housing.py &
