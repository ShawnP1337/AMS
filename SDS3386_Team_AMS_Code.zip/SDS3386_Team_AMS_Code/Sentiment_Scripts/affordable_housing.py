"""  Takes a folder as input containing all separated scraped twitter data related to a term. Combines all data into one csv,
then analyses sentiment on each tweet using vader, outputing a final with all scraped data as well as a column with calculated sentiment  """

import os
import pandas as pd
import glob
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer

path = "C:\\Users\\awyat049\\OneDrive\\Documents\\Coding\\2022_11_26_Cleaned_Twitter_Data\\affordable_housing"

os.chdir(path)

# to find output path later
shortpath = path[:76]

# to create new filenames later
filename = path[76:]

#converts numeric sentiment score into string classifier
#input: float64 sentiment_score
#output: string classifier as "Positive", "Negative", or "Neutral" sentiment
def calculateCompoundSentiment(sentiment_score):
    # decide sentiment as positive, negative and neutral based on numeric sentiment value
    if sentiment_score['compound'] >= 0.05 :
        return "Positive"
 
    elif sentiment_score['compound'] <= -0.05 :
        return "Negative"
 
    else :
        return "Neutral"


#uses vader to calculate numeric sentiment score of string
#input: string sentence - in this case a tweet
#output: string "sentiment_score, sentiment classifier"
## output example: '({'neg': 0.205, 'neu': 0.795, 'pos': 0.0, 'compound': -0.5574}, 'Negative')'
def getVaderSentimentScore(sentence):
    analyzer = SentimentIntensityAnalyzer()

    #calculates numeric sentiment score for negative, neutral, and positive sentiment
    sentiment_score = analyzer.polarity_scores(sentence)

    #classifies sentiment as negative, neutral or positive
    compoundSentiment = calculateCompoundSentiment(sentiment_score)
    return sentiment_score, compoundSentiment


extension = 'csv'

newname = filename + "_all_tweets.csv"

# collects all filenames in directory within a list
all_filenames = [i for i in glob.glob('*.{}'.format(extension))]

# reads files in directory and combines into one csv
combined_csv = pd.concat([pd.read_csv(f) for f in all_filenames ])

# drops all rows with blank tweets (result of removing incidental non-related tweets)
combined_csv = combined_csv.dropna(subset=["tweet"])

# outputs file of all combined scraped tweets
combined_csv.to_csv( newname, index=False, encoding='utf-8-sig')
combined_csv = None

newpath = shortpath + newname


data = pd.read_csv(newname)

# converts to numpy array for use by vader
tweetsArr = data['tweet'].to_numpy()
list = []

#analyses sentiment of each tweet and appends to final list
for tweet in tweetsArr:
    vs = getVaderSentimentScore(tweet)
    list.append(str(vs))

#adds sentiment list as column to original scraped data
data['Sentiment'] = list

finalfile = filename + '_all_tweets_sentiment'

#outputs file of all data including sentiment data as csv into new directory
data.to_csv(finalfile)