""" create a period column, for each tweet this holds the month the tweet was made. Create a 'compund_score' 
column that only holds the numeric calculated 'compound_score' of each tweet. Create a 'topic' column that holds 
the terms searched for to create the current dataset.Drop the date column and output new dataframe as a csv."""

import pandas as pd
import os 

datapath = "C:\\Users\\awyat049\\OneDrive\\Documents\\Coding\\Visualization\\inflation"
os.chdir(datapath)

inflation = pd.read_csv("inflation_DateTweetSent.csv")

# slices the string in the "Sentiment" column and creates a new "compound_score" column that only contains the compound sentiment score
# Drops the 'date' column and creates a 'topic' column holding the term searched for to create the dataset. Returns the new dataframe
# input: dataframe and filename dataframe was created from
# output: new datafram with 'period', 'compound_score', and 'topic' column added, plus 'date' column removed
def columns(df, file):
    
    # the compound score column
    first = ""
    second = ""
    score = []
    
    #splits 'Sentiment' column into just the compound score value
    for i in range(0,len(df['Sentiment'])):
        first = (df.iloc[i]['Sentiment']).split('compound')[1]
        second = (first.split('}'))[0]
        score.append( float((second.split(':'))[1]))
    
    df['compound_score'] = score
    
    # the period column (only the year and month from the date, it will be useful for time series)
    
    df['period'] = df['date'].str[:-3]

    df = df.drop(columns = 'date')
    
    # the topic column will also be useful for the graphs 
    
    term = file.replace('_DateTweetSent.csv', '')
    df['topic'] = term
    
    return df

inflation = columns(inflation, "inflation_DateTweetSent.csv")

#output new dataframe to csv
inflation.to_csv( "inflation_pre_graphs.csv", index=False, encoding='utf-8-sig')