These files are used to prepare the inflation dataset for analysis in a manageable way. This was done in stages to prevent crashes at any point and to allow reference to prior stages for analysis based on date rather than month.

Order run:

- makeInflationDataset.py
- makeInflationAgr.py
- makeInflationForGraph.py
- Inflation_Graph.ipynb

makeInflationDataset.py - drop unnecessary columns to anonymize data. Output new csv.

makeInflationAgr.py - create a period column, for each tweet this holds the month the tweet was made. Create a 'compund_score' column that only holds the numeric calculated 'compound_score' of each tweet. Create a 'topic' column that holds the terms searched for to create the current dataset. Drop the date column and output new dataframe as a csv.

makeInflationForGraph.py - aggregate sentiment score for all tweets in each period, and create new csv with only 'period', 'compound_score', and 'topic' column. Output said csv.

Inflation_Graph.ipynb - Check product of data creation through creating a graph of sentiment by month over time.