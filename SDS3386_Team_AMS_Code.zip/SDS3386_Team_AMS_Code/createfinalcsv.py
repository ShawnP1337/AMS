""" used to create csv files that are read in for analysis, this is done after the sentiment is calculated. 'compound_score'
column is created and populated using 'Sentiment' column. 'period' column is created signifying the month each tweet was made
'topic' column is created containing the search term used to generate the dataset. Additional mutually exclusive sentiment columns with values of
1 or 0 based on whether sentiment is Positive, Negative, or Neutral """

import pandas as pd
import os 

# this was used to create csv files that could be read in and analysed with any further data coding

# small functions that return 1 if the given tweet has the corresponding sentiment to the function
def Pos(x):
    if 'Positive' in x:
        return 1
    else:
        return 0
def Neg(x):
    if 'Negative' in x:
        return 1
    else:
        return 0
def Neu(x):
    if 'Neutral' in x:
        return 1
    else:
        return 0

# slices the string in the "Sentiment" column and creates a new "compound_score" column that only contains the compound sentiment score
# Creates mutually exclusive 'Positive Sentiment', 'Neutral Sentiment', and 'Negative Sentiment' columns with 1 as entry if the tweets
# sentiment corresponds to the column header. Creates a 'topic' column holding the term searched for to create the dataset. 
# Returns the new dataframe
# input: dataframe and filename dataframe was created from
# output: new datafram with 'period', 'compound_score', 'Positive Sentiment', 'Neutral Sentiment', 'Negative Sentiment', and 'topic' columns added
def columns(df, file):
    
    if 'Unnamed: 0' in df.columns:
        df = df.drop(columns=['Unnamed: 0'])
    
    # the compound score column
    #splits 'Sentiment' column into just the compound score value
    df[['compound']] = df['Sentiment'].str.split('compound', expand=True)[[1]]
    df[['compound_score']] = df['compound'].str.split('}', expand=True)[[0]]
    df[['compound_score']] = df['compound_score'].str.split(':', expand=True)[[1]].astype('float')
    df = df.drop(columns=['compound'])
    
    # the period column (only the year and month from the date, it will be useful for time series)
    df['period'] = df['date'].str[:-3]
    
    # the topic column will also be useful for the graphs 
    term = file.replace('_sentiment.csv', '')
    df['topic'] = term
    
    # Iterating over one column - `f` is some function that processes your data
    df['Positive Sentiment'] = [Pos(x) for x in df['Sentiment']]
    df['Neutral Sentiment'] = [Neu(x) for x in df['Sentiment']]
    df['Negative Sentiment'] = [Neg(x) for x in df['Sentiment']]

    
    return df



path = "C:\\Users\\awyat049\\OneDrive\\Documents\\Coding\\2022_12_05_Final_Data_ComboScore"


readpath= "C:\\Users\\awyat049\\OneDrive\\Documents\\Coding\\2022_11_29_Final_Data_Full\\"
os.chdir(readpath)

filename = "standard_of_living_sentiment.csv"

filepath = readpath + filename

data = pd.read_csv(filepath)

data = columns(data, filename)

os.chdir(path)

data.to_csv(filename, index=False, encoding='utf-8-sig')
