**Note: Within each folder is a separate README describing how that code is used.

Jupyter notebooks are split up for computer memory management. After the 'Final_Alex_Notebook_csv_create.ipynb' notebook is run (which can require up to 30 gb of ram), datasets for further use will be created, this notebook should be shut down to allow less memory intensive analysis going forward.

ORDER TO RUN:

ACTIVATE VIRTUAL ENVIRONMENT FOR SCRAPER
- there is a guide to do this in the scraping_and_proof_of_concepts folder as well as all necessary files.
 
scraper_util.py is within said folder, and is the parallel scraper

raw_dataset_cleaning_c++ folder
Sentiment_Scripts folder
inflation_processing_scripts_for_final_dataset folder
csv_utility_code folder (for inflation)
createfinalcsv.py (for non inflation sets)
// data scraping and sentiment calculation complete here

ANALYSIS (split up to not overrun RAM):
(conda_environment.yml include for this)

Final_Alex_Notebook_csv_create.ipynb - to create final tidy datasets

Final_Mariane_Notebook_Analysis.ipynb
- 1.	SUMMARY VISUALIZATIONS AND PRELIMINARY DATA DISCOVERIES
- 2.	HYPOTHESIS TESTING, VARIANCE IN SENTIMENT TOWARDS HOUSING PRICE AND PRICE IN GENERAL

Final_Alex_Notebook_Analysis.ipynb
- 3.	CORRELATION OF TERMS AND DIFFERENCES IN HOUSING PRICE AND PRICES IN GENERAL
- 4.	DIMENSIONALITY REDUCTION WITH TSNE
- 5.	MULTIVARIABLE REGRESSION FOR PREDICTION, AND DIMENSIONALITY REDUCTION WITH PCA

DATA VISUALIZATION DASHBOARD:

app.py - This file is the code for the panel dashboard. The Panel Dashbaord is hosted on https://ams-panel-dashboard.ue.r.appspot.com/app. 

To Run Panel Dashboard Locally 
panel serve app

Github Repo: https://github.com/ShawnP1337/AMS

** We also include code to produce wordclouds, we did this for all terms but there was no space to include them in the report, but they are included in the dashboard. Additionally, I included the clouds in a folder here since they're small in filesize. (wordcloud_code_not_used_in_final_report folder)
