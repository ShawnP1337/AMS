/* takes filepath as input, using 'clean_file(std::string filepath)' as driver, first determines filename using 'get_filename(std::string path)'
then reads in csv using 'csv_reader(std::string filepath)', which reads in data and separates into columns based on delimeters using
'get_csv_column(std::ifstream &in)', csv is returned to clean_file once complete, which then calls 'csv_writer(std::string filename, std::vector<std::string> vals)' 
processes the file and outputs a csv. Within said function, search term is determined using 'get_term(std::string filename)' and tweets are cleaned with 'clean_tweets.cpp' method
cleantweet(std::string term, std::string tweet)*/

#include <iostream>
#include <fstream>
#include <locale>
#include <string>
#include <vector>
#include <sstream>
#include <utility>
#include <stdexcept>
#include "clean_tweets.cpp"

int static numvalcol = 7;

/* takes an instream, reads until either two quotes are reached or a comma is reached outside of quotations returns the resulting
string which is a cell entry within the csv (main purpose is to not delimit by commas within tweets)
input: instream
output: a cell within the read in csv
*/
std::string get_csv_column(std::ifstream &in)
{
    // so this is the actual reading object passed here
    // this function looks at one block and returns when it hits an appropriate point (measure by conditions)
    // thus, when it returns, we are at the exact place in the reader where it returns
    std::string col;
    unsigned quotes = 0;
    char prev = 0;

    //flag to track when to break loop
    bool finis = false;

    for (int ch; !finis && (ch = in.get()) != EOF; ) {
        // to catch cases
        switch(ch) {
        
        // if quotations, add 1 to quotation counter
        case '"':
            ++quotes;
            break;

        // if comma and no quotation are read, or comma is preceded by quotation and number quotations is 0 or 2 set finish
        // condition to true
        case ',':
            if (quotes == 0 || (prev == '"' && (quotes & 1) == 0)) {
                finis = true;
            }
            break;
        
        // if newline character, and quotes read is zero or two, set finish condition to true
        case '\n':
            if (quotes == 0|| ((quotes & 1) == 0)) {
                finis = true;
            }
            break;
        default:;
        }
        //make each character lowercase (for ease of processing tweets)
        ch = std::tolower(ch);

        //add character to current cell
        col += prev = ch;
    }
    //return cell
    return col;
}

/* takes filename (standardized naming convention used in scraping), outputs term that was used to generate set
input: filename string
output: term searched for scraping
standardized filename: "search_term[datetime.date(year, month, day), datetime.date(year, month, day)].csv" */
std::string get_term(std::string filename) {
    std::string term;

    // loop used to identify terms
    for (char &c : filename) {
        switch(c) {
        
        //when '[' reached, term is identified, exit loop]
        case '[':
            goto end_loop;

        //replace '_' with a space
        case '_':
            c = ' ';
        default:;
        }

        //convert character to lowercase
        c = std::tolower(c);
        term += c;
    }
    end_loop: ;

    // print term to track file processing with terminal (and ensure terms are correctly identified)
    std::cout << term << "\n";

    return term;
}

/* Take filepath and return isolated filename
input: string filepath
output: string filename*/
std::string get_filename(std::string path) {
    std::string filename;
    std::string base_filename = path.substr(path.find_last_of("/\\") + 1);
    std::string::size_type const p(base_filename.find_last_of('.'));
    return base_filename.substr(0, p);
}

/* take filepath, read file by calling 'get_csv_column(std::ifstream &in) to separate into different cells*/
std::vector<std::string> csv_reader(std::string filepath) {
    std::ifstream myFile(filepath);

    if(!myFile.is_open()) throw std::runtime_error("Could not open file");

    // stores csv by column
    std::vector<std::string> result;

    // iterate through file where each iteration the instream is at the beginning of a cell, the stream is passed to the 
    // get_csv_column() function, and said function iterates through the stream identifying the end of said cell and returning
    // its contents
    for (std::string col; myFile; ) {

        col = get_csv_column(myFile);
        result.push_back(col);
    }

    myFile.close();

    return result;
}


/* Creates new output file based on input filename, identifies search term, calls clean_tweets.cpp utility to clean, then
uses a loop and counter to identify columns with tweets, clean said tweets, and write them to the final csv
input: filename and vector of csv contents
output: integer signifying success '0' and a new csv file with tweets processed for sentiment analysis*/
int csv_writer(std::string filename, std::vector<std::string> vals) {

    // create outstream
    std::ofstream myFile(filename+"_clean.csv");

    int numrows = vals.size();

    // to skip the column header for tweet column
    int counter = 0 - numvalcol;

    // flag for tweets that are removed, to not add rest of cells in that line
    bool skip = false;
    std::string cleaned;

    // identify searchterm to scrape dataset
    std::string term = get_term(filename);

    for(std::string i : vals) {

        // if counter less than 0, headers have not yet been read in, or date is not read in
        if (counter < 0) {
            // if date not read in, write to file -- this is just for clarity
            if (counter == -1) {
                myFile << i;
            }
            else {
                myFile << i;
            }
        }
        // do not read in any data if skip is true, until last column is reached, then write new line to csv to move to next line
        else if (skip == true) {
            if (counter == numvalcol - 1) {
                myFile << "\n";
                counter = -1;
                skip = false;
            }
        }
        // if skip false and on last column, write current cell to file and reset counter to -1
        else if (counter == numvalcol - 1) {
            myFile << i;
            counter = -1;

        } 
        // identifies column with tweet, cleans tweet
        else if (counter == 1) {
            cleaned = cleantweet(term,i);

            // if term not in tweet after cleaning, blank string returned, signifies to skip writing remaining cells in 
            // row
            if (cleaned == "") {
                skip = true;
            } 
            else {
                myFile << cleaned;
            }  
        }
        else {
            myFile << i;
        }

        counter++; 
    }
    myFile.close();
    
    return 0;
}

int clean_file(std::string filepath) {
    std::string filename = get_filename(filepath);

    std::vector<std::string> data = csv_reader(filepath);
    csv_writer(filename, data);

    return 0;
}

