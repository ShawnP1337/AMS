/* DO NOT RUN THIS PROFESSOR (unless you have a really powerful cpu). I have a 14 physical core system meant for overclocking
with decently good clockspeed and very good cooling and this topped it. 

Code iterates through all folders in directory (outer loop) then all files in each folder (inner loop), creates a thread
for each file until 4*number of hardware capable threads is reached, then joins threads, clears and continues to next iteration*/

#include <string>
#include <iostream>
#include <filesystem>
#include <thread>
#include <vector>
#include "tweet_clean_util.cpp"
namespace fs = std::filesystem;

int main() {
    //std::string path_folders = "C:\\Users\\awyat049\\OneDrive\\Documents\\Coding\\2022_11_14_Twitter_Data";
    std::string path_folders = "D:\\Documents\\Coding\\C++\\twitter_data_cleaning\\testsets\\final";
    
    std::string filepath;
    std::vector<std::thread> threads;

    // save integer of number of threads computer is capable of producing
    int numThreads = std::thread::hardware_concurrency();
    int count = 0;

    //std::string path_folders = "C:/Users/awyat049/OneDrive/Documents/Coding/2022_11_14_Twitter_Data";

    //Iterate through all folders in the directory
    for (const auto &entry : fs::directory_iterator(path_folders)) {

        //iterates through all files in the folder
        for (const auto &file : fs::directory_iterator(entry.path())) {
            filepath = (file.path()).string();

            //creates thread and assigns current file
            threads.push_back(std::thread(clean_file,filepath));
            //clean_file(filepath);
            if (count == 4*numThreads) {
                for (auto &th : threads) {
                    th.join();
                }
                count = 0;
                threads.clear();
            }
            count++;
        }

    }

    // joins remaining threads if number of files is not divisible by 4
    for (auto &th : threads) {
                    th.join();
                }
                count = 0;
                threads.clear();

    return 0;
}
