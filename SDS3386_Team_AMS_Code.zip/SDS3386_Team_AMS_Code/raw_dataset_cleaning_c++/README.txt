These files were the first cleaning that was done after scraping. Work was done in C++ for speed, and parallel programming is used to automatically assign cleaning tasks to threads and perform all cleaning without need for user interaction.

How it works:

'auto_clean.cpp' is called, which assigns threads for files to be cleaned and cleans with 'tweet_clean_util.cpp', which cleans each independent tweet using 'clean_tweets.cpp'

Only auto_clean.cpp is to be run, all the rest are different purpose build programs to logically separate tasks.