/* utility to clean tweets, removes all hashtags, and usernames (signified by strings begining with @ symbol) if after removal,
search term is no longer present, returns an empty string to signify that tweet should not be analysed. */

#include <iostream>
#include <string>
#include <sstream>
#include <regex>

// uses regex to remove all terms beginning with hashtags
// input: string representing a tweet
// output: same string with all hashtag statements removed
std::string remove_hashtag(std::string tweet) {
    std::regex hashtag ("#+[a-zA-Z0-9(_)]{1,}");

    return std::regex_replace(tweet,hashtag, "");
}

// uses regex to remove all terms beginning with @ symbol
// input: string representing a tweet
// output: same string with all @ statements removed
std::string remove_at(std::string tweet) {
    std::regex at ("@+[a-zA-Z0-9(_)]{1,}");

    return std::regex_replace(tweet,at, "");
}

// checks if the search term is within the tweet, if not, returns a blank tweet, if so, returns the current tweet
// input: string search term, string tweet
// output: blank string if search term not in tweet, original tweet otherwise
std::string check_match(std::string term, std::string tweet) {

    // string stream which parses search term based on whitespace delimiters
    std::istringstream iss (term);
    std::string tmp;

    // loop using regex to check if each whitespace delimited term from the search term is within tweet
    while (iss >> tmp) {
        if (std::regex_search(tweet, std::regex(tmp))) {
            continue;
        }
        // if a part of the search term is not in the tweet, returns an empty string
        return "";
    }

    return tweet;
}

// driver function, calls other functions to process tweet and returns processed tweets
// input: string search term, string tweet
// output: processed tweet without hashtag statements, @ statements and containing search term, 
// or empty string if not containing search term
std::string cleantweet(std::string term, std::string tweet) {

    std::string tweetnohash = remove_hashtag(tweet);
    std::string tweetclean = remove_at(tweetnohash);
    return check_match(term, tweetclean);
}